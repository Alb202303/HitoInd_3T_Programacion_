/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.colecciones;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 *
 * @author Campus FP
 */
public class Tabla {
     public static void main(String[] args) {
        Hashtable EjemploTabla=new Hashtable();

        EjemploTabla.put("1", "Uno");
        EjemploTabla.put("2", "Dos");
        EjemploTabla.put("3", "Tres");
        EjemploTabla.put("4", "Cuatro");

        Enumeration keys = EjemploTabla.keys();
        while (keys.hasMoreElements())
        {
            System.out.println(keys.nextElement());
        }

        Enumeration valores = EjemploTabla.elements();
        while (valores.hasMoreElements())
        {
            System.out.println(valores.nextElement());
        }


    }
    
}
