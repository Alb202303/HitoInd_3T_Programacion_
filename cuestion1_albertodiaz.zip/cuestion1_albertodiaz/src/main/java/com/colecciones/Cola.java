/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.colecciones;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Campus FP
 */
public class Cola {
     public static void main(String[] args) {
        Queue<String> listanombres = new LinkedList<>();

        listanombres.offer("Alberto");
        listanombres.offer("Javier");
        listanombres.offer("Luquero");
        listanombres.offer("Iván");
        listanombres.offer("Astrid");
        
        System.out.println("Cola: " + listanombres);

        String delete = listanombres.poll();
        System.out.println("Nombre eliminado: " + delete);

       
    }
}
