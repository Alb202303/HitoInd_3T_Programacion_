/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.colecciones;

import java.util.ArrayList;

/**
 *
 * @author Campus FP
 */
public class Lista {
    public static void main(String[] args) {
                java.util.List<String> listaciudades=new ArrayList<String>();

                listaciudades.add("Madrid");
                listaciudades.add("Barcelona");
                listaciudades.add("Sevilla");
                listaciudades.add("Valencia");


                for(String persona:listaciudades)
                    System.out.println(persona);
    }
    
}
