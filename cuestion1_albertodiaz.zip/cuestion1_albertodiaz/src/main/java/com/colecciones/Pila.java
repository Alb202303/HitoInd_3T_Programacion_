/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.colecciones;

import java.util.Stack;

/**
 *
 * @author Campus FP
 */
public class Pila {
     public static void main(String[] args) {

        Stack<String> EjemploPila= new Stack<>();


        EjemploPila.push("Programación");
        EjemploPila.push("L.Marcas");
        EjemploPila.push("BBDD");
        EjemploPila.push("FOL");
        EjemploPila.push("Entornos");
        EjemploPila.push("Sistemas informáticos");


       

        System.out.println("Asignaturas: " + EjemploPila);
        boolean recorrerlista = EjemploPila.empty();
        
    }
    
}
