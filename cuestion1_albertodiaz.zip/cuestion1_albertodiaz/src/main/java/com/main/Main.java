/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.main;

import com.clases.Hija;
import com.clases.Padre;

/**
 *
 * @author Campus FP
 */
public class Main {

	public static void main(String[] args) {
		
		//Herencia
		System.out.println("HERENCIA");

		Hija hija=new Hija("Natalia", "Díaz", 18, "2ºBachillerato", "Rosa" );
		
		hija.mostrarInfo();
		
		//Sobreescritura
		
		System.out.println("SOBREESCRITURA");
		Padre.Sobreescritura();
		Hija.Sobreescritura();
		
		//Sobrecarga
		System.out.println("SOBRECARGA");

		Padre padre1=new Padre("Fernando", "Rojas", 32);
		padre1.Correr();
		padre1.Correr(3);
		
		
	}

}

